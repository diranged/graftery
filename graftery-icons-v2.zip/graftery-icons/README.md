# Graftery Icon Set — V2

## Concept
Asymmetric graft metaphor: thick rootstock (left) + thin wiggly scion (upper-right) converge
at a coral union band, generating ephemeral macOS VMs below.

## VM lifecycle (top to bottom)
- Ghost dashed box = destroyed VM
- Solid coral band = running VM / graft union point  
- Open-bottom forming box = VM being assembled

## Color palette
- Background: #0a1a20 (dark teal)
- Rootstock: #0e6878
- Scion: #1aabb8
- Union band: #c94a30 (coral)

## Files
- graftery-icon-v1-master.svg    — V1 master (symmetric dual helix)
- graftery-icon-v2-master.svg    — V2 master (1024×1024, asymmetric)
- graftery-icon-512.svg          — App icon, 512pt, full detail
- graftery-icon-128.svg          — Dock/Finder, 128pt, simplified
- graftery-menubar-color-dark.svg  — Menu bar 22pt, color on dark
- graftery-menubar-mono-light.svg  — Menu bar 22pt, monochrome template

## Next steps
- Export PNGs at 1x/2x/3x from the SVGs
- Hand-tune 16pt favicon version
- Design wordmark lockup
